# Sükûnet (static)
Static single-file app. Deployed via GitHub Pages.

How to enable Pages (quick):
1) Push these files to a repo (public).
2) Settings → Pages → Build and deployment: Deploy from a branch.
3) Branch: main, Folder: /(root). Save.
4) Open: https://USERNAME.github.io/REPO/
